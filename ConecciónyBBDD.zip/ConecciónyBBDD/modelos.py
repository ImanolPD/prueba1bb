from sqlalchemy import create_engine
from sqlalchemy import Column, Integer, String, Date, DateTime, Boolean
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import declarative_base

#Importar lo necesario para poder llamar y obtener los datos de la url
import requests
import json
import read

# URL de la API de JSONPlaceholder para obtener datos de usuarios
actual="https://www.thesportsdb.com/api/v1/json/3/lookuptable.php?l=4328&s=2024-2025"
Tempo2023="https://www.thesportsdb.com/api/v1/json/3/lookuptable.php?l=4328&s=2023-2024"
Tempo2022="https://www.thesportsdb.com/api/v1/json/3/lookuptable.php?l=4328&s=2022-2023"
Tempo2021="https://www.thesportsdb.com/api/v1/json/3/lookuptable.php?l=4328&s=2021-2022"
Tempo2020="https://www.thesportsdb.com/api/v1/json/3/lookuptable.php?l=4328&s=2020-2021"
Tempo2019="https://www.thesportsdb.com/api/v1/json/3/lookuptable.php?l=4328&s=2019-2020"



# Realiza una solicitud GET a la API
response1 = requests.get(actual)
response2 = requests.get(Tempo2023)
response3 = requests.get(Tempo2022)
response4 = requests.get(Tempo2021)
response5 = requests.get(Tempo2020)
response6 = requests.get(Tempo2019)

# Verifica si la solicitud fue exitosa (código de respuesta 200)
if response1.status_code == 200 or response2.status_code == 200 or response3.status_code == 200 or response4.status_code == 200 or response5.status_code == 200 or response6.status_code == 200:
    # print(response.text) el contenido de la respuesta como una cadena de texto.
    # Utiliza json.loads() para analizar la respuesta JSON
    #data = json.loads(response.text)
    JsonRanking =[ response1.json(), response2.json(), response3.json(), response4.json(), response5.json(), response6.json()]
    #print("Datos de usuarios de JSONPlaceholder:")
    #print(JsonRanking)
else:
    print(f"Error en la solicitud. Código de respuesta: {response1.status_code}")
    print(f"Error en la solicitud. Código de respuesta: {response2.status_code}")
    print(f"Error en la solicitud. Código de respuesta: {response3.status_code}")
    print(f"Error en la solicitud. Código de respuesta: {response4.status_code}")
    print(f"Error en la solicitud. Código de respuesta: {response5.status_code}")
    print(f"Error en la solicitud. Código de respuesta: {response6.status_code}")



# Configurar la conexión a la base de datos PostgreSQL
engine = create_engine("postgresql://bryanBlu:bryan007@localhost:5433/Reto3")
Base = declarative_base()

Session = sessionmaker(bind=engine)
def abrir_sesion():
    return Session()

def cerrar_sesion(session):
# Cerrar la sesión al terminar
    session.close()

class miCRUD:
    def create(self, Session):
        Session.add(self)
        Session.commit()

    @classmethod
    def read(cls, Session, **consulta):
        return Session.query(cls).filter_by(**consulta).all() #devuelve una lista de objetos
        #return Session.query(cls).all()

    def update(self,Session):
        Session.commit()

    def delete(self, Session):
        Session.delete(self)
        Session.commit()
    

# Clase que representa la tabla 'Usuario'
class Usuario(Base,miCRUD):
    __tablename__ = 'Usuarios'
    idUsuario = Column(Integer, primary_key=True)
    nombre = Column(String)
    correoElectronico = Column(String)
    contrasena= Column(String)
    registrado= Column(Boolean)
    comentario= Column(String)

# Clase que representa la tabla 'Ranking'
class Ranking(Base,miCRUD):
    __tablename__ = 'Rankings'
    idRanking = Column(Integer, primary_key=True)
    logo = Column(Integer)
    nombre = Column(String)
    posicion = Column(Integer)
    partidos = Column(Integer)
    victorias = Column(Integer)
    empates = Column(Integer)
    derrotas = Column(Integer)
    puntos = Column(Integer)
    NTempo = Column(String)


# Clase que representa la tabla 'Evento'
class Evento(Base,miCRUD):
    __tablename__ = 'Eventos'
    idEvento = Column(Integer, primary_key=True)
    nombreEquipos = Column(String)
    fecha = Column(DateTime)
    temporada = Column(Integer)
    golesVisitante = Column(Integer)
    golesCasa = Column(Integer)

Base.metadata.create_all(engine)




# Crear una sesión para interactuar con la base de datos
#Session = sessionmaker(bind=engine) 

nuevaSe= Session()

#Función para añadir datos a la BBDD
#print(JsonRanking["table"][0].get("intRank"))

for y in range(0,6):  

    nuevo_Ranking0=[]
    nuevo_Ranking1=[]
    nuevo_Ranking2=[]
    nuevo_Ranking3=[]
    nuevo_Ranking4=[]
    nuevo_Ranking5=[]
    nuevo_Ranking6=[]
    nuevo_Ranking7=[]
    nuevo_Ranking8=[]
    nuevo_Ranking9=[]
    nuevo_Ranking10=[]
    nuevo_Ranking11=[]
    nuevo_Ranking12=[]
    nuevo_Ranking13=[]
    nuevo_Ranking14=[]
    nuevo_Ranking15=[]
    nuevo_Ranking16=[]
    nuevo_Ranking17=[]
    nuevo_Ranking18=[]
    nuevo_Ranking19=[]

    tabla=[nuevo_Ranking0, nuevo_Ranking1,nuevo_Ranking2, nuevo_Ranking3, nuevo_Ranking4,
    nuevo_Ranking5, nuevo_Ranking6, nuevo_Ranking7, nuevo_Ranking8, nuevo_Ranking9,
    nuevo_Ranking10, nuevo_Ranking11, nuevo_Ranking12, nuevo_Ranking13, nuevo_Ranking14,
    nuevo_Ranking15, nuevo_Ranking16, nuevo_Ranking17, nuevo_Ranking18, nuevo_Ranking19]

    for i in range(0,20):
        tabla[i] = Ranking(logo=i, nombre=JsonRanking[y]["table"][i].get("strTeam"), 
        posicion=JsonRanking[y]["table"][i].get("intRank"), partidos=JsonRanking[y]["table"][i].get("intPlayed"),
        victorias=JsonRanking[y]["table"][i].get("intWin"), empates=JsonRanking[y]["table"][i].get("intDraw"), 
        derrotas=JsonRanking[y]["table"][i].get("intLoss"), puntos=JsonRanking[y]["table"][i].get("intPoints"),
        NTempo=JsonRanking[y]["table"][i].get("strSeason"))
        nuevaSe.add_all([tabla[i]])

    nuevaSe.commit()
    nuevaSe.close()
    

def AñadirDatosActualizados(): #Actualizar los datos cada semana
    nuevaSe= Session()       
    nuevo_Ranking0=[]
    nuevo_Ranking1=[]
    nuevo_Ranking2=[]
    nuevo_Ranking3=[]
    nuevo_Ranking4=[]
    nuevo_Ranking5=[]
    nuevo_Ranking6=[]
    nuevo_Ranking7=[]
    nuevo_Ranking8=[]
    nuevo_Ranking9=[]
    nuevo_Ranking10=[]
    nuevo_Ranking11=[]
    nuevo_Ranking12=[]
    nuevo_Ranking13=[]
    nuevo_Ranking14=[]
    nuevo_Ranking15=[]
    nuevo_Ranking16=[]
    nuevo_Ranking17=[]
    nuevo_Ranking18=[]
    nuevo_Ranking19=[]

    tabla=[nuevo_Ranking0, nuevo_Ranking1,nuevo_Ranking2, nuevo_Ranking3, nuevo_Ranking4,
    nuevo_Ranking5, nuevo_Ranking6, nuevo_Ranking7, nuevo_Ranking8, nuevo_Ranking9,
    nuevo_Ranking10, nuevo_Ranking11, nuevo_Ranking12, nuevo_Ranking13, nuevo_Ranking14,
    nuevo_Ranking15, nuevo_Ranking16, nuevo_Ranking17, nuevo_Ranking18, nuevo_Ranking19]
    
    for i in range(0,19):
        consulta={"idRanking": (i+1)}
        tabla[i] = Ranking.read(nuevaSe,**consulta)[0]
        tabla[i].logo=i+1
        tabla[i].nombre=JsonRanking[0]["table"][i].get("strTeam")
        tabla[i].posicion=JsonRanking[0]["table"][i].get("intRank") 
        tabla[i].partidos=JsonRanking[0]["table"][i].get("intPlayed")
        tabla[i].victorias=JsonRanking[0]["table"][i].get("intWin") 
        tabla[i].empates=JsonRanking[0]["table"][i].get("intDraw")
        tabla[i].derrotas=JsonRanking[0]["table"][i].get("intLoss")
        tabla[i].puntos=JsonRanking[0]["table"][i].get("intPoints")   
        tabla[i].update(nuevaSe)        
    nuevaSe.commit()
    nuevaSe.close()

#Importar lo necesario para hacer la función de actualuizar cada cierto tiempo
import time
import threading
#Función para actualizar
def ejecutar_codigo():
    # Aquí va el código que deseas ejecutar cada 30 segundos
    AñadirDatosActualizados()
    #Ejemplo: ejecutar un script Python
    #exec(open("modelos.py").read()) Para abrir uno de los archivos y ejecutarlo o leerlo

def main():
    while True:
        ejecutar_codigo()
        time.sleep(604800)  # Espera 7 dias, segundos

# Inicia el hilo principal
threading.Thread(target=main).start()
