from wsgiref.simple_server import make_server
from urllib.parse import parse_qs
import vistas
import modelos

def leerRanking():
    sesion = modelos.abrir_sesion()
    consulta0 = {"idRanking": 1}
    nuevo_Ranking0= modelos.Ranking.read(sesion, **consulta0)
    consulta1 = {"idRanking": 2}
    nuevo_Ranking1= modelos.Ranking.read(sesion, **consulta1)
    consulta2 = {"idRanking": 3}
    nuevo_Ranking2= modelos.Ranking.read(sesion, **consulta2)
    consulta3 = {"idRanking": 4}
    nuevo_Ranking3= modelos.Ranking.read(sesion, **consulta3)
    consulta4 = {"idRanking": 5}
    nuevo_Ranking4= modelos.Ranking.read(sesion, **consulta4)
    consulta5 = {"idRanking": 6}
    nuevo_Ranking5= modelos.Ranking.read(sesion, **consulta5)
    consulta6 = {"idRanking": 7}
    nuevo_Ranking6= modelos.Ranking.read(sesion, **consulta6)
    consulta7 = {"idRanking": 8}
    nuevo_Ranking7= modelos.Ranking.read(sesion, **consulta7)
    consulta8 = {"idRanking": 9}
    nuevo_Ranking8= modelos.Ranking.read(sesion, **consulta8)
    consulta9 = {"idRanking": 10}
    nuevo_Ranking9= modelos.Ranking.read(sesion, **consulta9)
    consulta10 = {"idRanking": 11}
    nuevo_Ranking10= modelos.Ranking.read(sesion, **consulta10)
    consulta11 = {"idRanking": 12}
    nuevo_Ranking11= modelos.Ranking.read(sesion, **consulta11)
    consulta12 = {"idRanking": 13}
    nuevo_Ranking12= modelos.Ranking.read(sesion, **consulta12)
    consulta13 = {"idRanking": 14}
    nuevo_Ranking13= modelos.Ranking.read(sesion, **consulta13)
    consulta14 = {"idRanking": 15}
    nuevo_Ranking14= modelos.Ranking.read(sesion, **consulta14)
    consulta15 = {"idRanking": 16}
    nuevo_Ranking15= modelos.Ranking.read(sesion, **consulta15)
    consulta16 = {"idRanking": 17}
    nuevo_Ranking16= modelos.Ranking.read(sesion, **consulta16)
    consulta17 = {"idRanking": 18}
    nuevo_Ranking17= modelos.Ranking.read(sesion, **consulta17)
    consulta18 = {"idRanking": 19}
    nuevo_Ranking18= modelos.Ranking.read(sesion, **consulta18)
    consulta19 = {"idRanking": 20}
    nuevo_Ranking19= modelos.Ranking.read(sesion, **consulta19)
    modelos.cerrar_sesion(sesion) #ponemos barra invertida para que siga con la progresion en el salto de línea
    sesion = None

    return nuevo_Ranking0, nuevo_Ranking1, nuevo_Ranking2, nuevo_Ranking3, nuevo_Ranking4,\
    nuevo_Ranking5, nuevo_Ranking6, nuevo_Ranking7, nuevo_Ranking8, nuevo_Ranking9,\
    nuevo_Ranking10, nuevo_Ranking11, nuevo_Ranking12, nuevo_Ranking13, nuevo_Ranking14,\
    nuevo_Ranking15, nuevo_Ranking16, nuevo_Ranking17, nuevo_Ranking18, nuevo_Ranking19

    
   
    

# Definir función para añadir productos.
def add_product(environ, start_response):
    if environ['REQUEST_METHOD'] == 'POST':
        try:
            # Leer y parsear los datos del formulario
            # size 0 si la cabecera CONTENT_LENGTH no está definida
            size = int(environ.get('CONTENT_LENGTH', 0))
            # convertir en cadena de texto
            data = environ['wsgi.input'].read(size).decode()
            params = parse_qs(data) # diccionario con clave y valor (lista, aunque sólo haya un valor)            
            # Crear y guardar el nuevo producto
            producto = modelos.Producto(
                producto=params['producto'][0],
                modelo=params['modelo'][0],
                precio=float(params['precio'][0])
            )
            sesion = modelos.abrir_sesion()
            producto.create(sesion)
            modelos.cerrar_sesion(sesion)
            sesion = None
            # Redirigir a la página principal
            # '303 See Other' indica que se debe realizar una solicitud GET a la 
            # URL especificada en Location, en este caso -> '/es'
            start_response('303 See Other', [('Location', '/es')])
            # hay que devolver cadena de bytes
            return [b''] # cuerpo de la respuesta vacío porque no necesitamos enviar contenido adicional
            # finaliza la respuesta, permitiendo que el navegador procese la redirección hacia '/es'
        except Exception as e:
            start_response('500 Internal Server Error', [('Content-type', 'text/plain')])
            return [str(e).encode('utf-8')]
    else:
        return vistas.handle_404(environ, start_response)


# Definir la función app que manejará las solicitudes.
def app(environ, start_response):
    path = environ.get('PATH_INFO')
    # print('path: ', path)
    if path == '/':
        return vistas.english_handle_index(environ, start_response)
    elif path == '/es':
        Rankings = leerRanking()
        return vistas.spanish_handle_index(environ, start_response, Rankings)
    elif path == '/add_product':
        return add_product(environ, start_response)
    elif path.startswith('/static/'):
        return vistas.serve_static(environ, start_response)
    else:
        return vistas.handle_404(environ, start_response)


if __name__ == "__main__":
    host = 'localhost'
    port = 8000

    httpd = make_server(host, port, app)
    print(f"Servidor en http://{host}:{port}")
    httpd.serve_forever()
'''
Una vez ejecutado el controlador, podemos acceder a través del navegador, 
con las rutas: http://localhost:8000/    (no se usa jinja2)
y   http://localhost:8000/es, esta segunda usa jinja2.
Con la url http://localhost:8000/static/ se mostrará el archivo css.
Si se pone una url diferente, saldrá el mensaje de 'página no encontrada'
'''

""" {% for datos2 in nuevo_Ranking2: %}
{% for datos3 in nuevo_Ranking3: %}
{% for datos4 in nuevo_Ranking4: %}
{% for datos5 in nuevo_Ranking5: %}
{% for datos6 in nuevo_Ranking6: %}
{% for datos7 in nuevo_Ranking7: %}
{% for datos8 in nuevo_Ranking8: %}
{% for datos9 in nuevo_Ranking9: %}
{% for datos10 in nuevo_Ranking10: %}
{% for datos11 in nuevo_Ranking11: %}
{% for datos12 in nuevo_Ranking12: %}
{% for datos13 in nuevo_Ranking13: %}
{% for datos14 in nuevo_Ranking14: %}
{% for datos15 in nuevo_Ranking15: %}
{% for datos16 in nuevo_Ranking16: %}
{% for datos17 in nuevo_Ranking17: %}
{% for datos18 in nuevo_Ranking18: %}
{% for datos19 in nuevo_Ranking19: %} """